/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 8.0.18 : Database - library
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`library` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `library`;

/*Table structure for table `author` */

DROP TABLE IF EXISTS `author`;

CREATE TABLE `author` (
  `name` varchar(10) NOT NULL DEFAULT '',
  `workplace` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `author` */

insert  into `author`(`name`,`workplace`) values 
('建国','盐城'),
('张三','北京'),
('李四','上海'),
('李娜','北京'),
('狗蛋','南京'),
('王五','武汉'),
('田七','重庆'),
('申九','北京'),
('老八','北京'),
('萧恕','上海'),
('请问','是大法官'),
('请问2','是大法官'),
('赵六','天津'),
('铁柱','大连');

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `idBook` varchar(10) NOT NULL DEFAULT '',
  `nameBook` varchar(15) DEFAULT NULL,
  `price` int(4) DEFAULT NULL,
  `kind` varchar(8) DEFAULT NULL,
  `author` varchar(10) NOT NULL DEFAULT '',
  `publisher` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`idBook`),
  KEY `namePublisher` (`publisher`),
  KEY `nameAuthor` (`author`),
  CONSTRAINT `nameAuthor` FOREIGN KEY (`author`) REFERENCES `author` (`name`),
  CONSTRAINT `namePublisher` FOREIGN KEY (`publisher`) REFERENCES `publisher` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `book` */

insert  into `book`(`idBook`,`nameBook`,`price`,`kind`,`author`,`publisher`) values 
('001','阿道夫',22,'请问','请问','请问3'),
('002','阿道夫',22,'请问','请问','请问'),
('005','资本论',26,'哲学','李四','人民出版社'),
('006','围城',18,'小说','田七','人民出版社'),
('010','阿道夫',22,'请问','请问','请问'),
('011','Java语言程序设计',65,'教材','铁柱','机械工业出版社'),
('012','阿道夫',22,'请问','请问','请问'),
('013','阿道夫',22,'请问','请问','请问'),
('014','阿道夫',22,'请问','请问','请问'),
('015','阿道夫',22,'请问','请问','请问'),
('017','阿道夫',22,'请问','请问','请问3'),
('018','阿道夫',22,'请问','请问','请问'),
('019','阿道夫',22,'请问','请问','请问3'),
('020','阿道夫',22,'请问','请问','请问3'),
('021','阿道夫',22,'请问','请问','请问3');

/*Table structure for table `borrow` */

DROP TABLE IF EXISTS `borrow`;

CREATE TABLE `borrow` (
  `idReader` varchar(10) NOT NULL DEFAULT '',
  `idBook` varchar(10) DEFAULT NULL,
  `lendDate` date NOT NULL DEFAULT '2020-06-04',
  `dueDate` date NOT NULL DEFAULT '2020-12-19',
  `overtime` varchar(4) NOT NULL DEFAULT '否',
  UNIQUE KEY `idBook` (`idBook`),
  KEY `idReader` (`idReader`),
  CONSTRAINT `Book` FOREIGN KEY (`idBook`) REFERENCES `book` (`idBook`),
  CONSTRAINT `Reader` FOREIGN KEY (`idReader`) REFERENCES `reader` (`idReader`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `borrow` */

insert  into `borrow`(`idReader`,`idBook`,`lendDate`,`dueDate`,`overtime`) values 
('002','006','2020-01-01','2020-03-01','否'),
('007','011','2020-01-01','2020-03-01','否'),
('001','002','2020-06-27','2020-05-05','否'),
('001','001','2020-06-28','2020-08-28','否'),
('001','005','2020-06-29','2020-08-29','否');

/*Table structure for table `librarian` */

DROP TABLE IF EXISTS `librarian`;

CREATE TABLE `librarian` (
  `nameUser` varchar(10) NOT NULL DEFAULT '',
  `password` varchar(10) NOT NULL DEFAULT 'root'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `librarian` */

insert  into `librarian`(`nameUser`,`password`) values 
('root','root');

/*Table structure for table `publisher` */

DROP TABLE IF EXISTS `publisher`;

CREATE TABLE `publisher` (
  `name` varchar(20) NOT NULL DEFAULT '',
  `address` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `publisher` */

insert  into `publisher`(`name`,`address`) values 
('中信出版社','上海'),
('人民出版社','北京'),
('华夏出版社','武汉'),
('商务印书出版社','天津'),
('机械工业出版社','上海'),
('清华大学出版社','北京'),
('百花文艺出版社','武汉'),
('请问','大公司'),
('请问3','大公司');

/*Table structure for table `reader` */

DROP TABLE IF EXISTS `reader`;

CREATE TABLE `reader` (
  `idReader` varchar(10) NOT NULL DEFAULT '',
  `nameReader` varchar(10) DEFAULT NULL,
  `kind` varchar(6) DEFAULT '学生',
  `sex` varchar(4) NOT NULL DEFAULT '男',
  `password` varchar(10) NOT NULL DEFAULT 'root',
  PRIMARY KEY (`idReader`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `reader` */

insert  into `reader`(`idReader`,`nameReader`,`kind`,`sex`,`password`) values 
('001','学生1号','学生','女','root'),
('002','学生2号','学生','女','root'),
('003','学生3号','学生','女','root'),
('004','学生4号','学生','女','root'),
('005','学生5号','学生','女','root'),
('006','学生6号','学生','男','root'),
('007','学生7号','学生','男','root'),
('008','学生8号','学生','男','root'),
('009','教师1号','教师','男','root'),
('010','教师2号','教师','女','root');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
