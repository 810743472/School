package Servlet;

import entity.Book;
import entity.Borrow;
import sqlTools.BookTools;
import sqlTools.BorrowTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletReaderDue")
public class ServletReaderDue extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BookTools bookTools = new BookTools();
        BorrowTools borrowTools = new BorrowTools ();
        List<Borrow> borrowid =borrowTools.selcetAll();
        List<Book> books = new ArrayList<> ();
        List<String> listID = new ArrayList<> ();

        String LoginName =new String ( request.getParameter ("LoginName").getBytes ("iso-8859-1"), "utf-8");
        String idbook =new String ( request.getParameter ("bookid").getBytes ("iso-8859-1"), "utf-8");
        int cherk = 0;
        //把读者借的所有书保存集合
        for (Borrow borrow : borrowid) {
            if (LoginName.equals (borrow.getIdReader ())){
                books.add (bookTools.Search_Book (borrow.getIdBook ()));
            }
        }

        if (idbook != null && !"".equals (idbook)) {
            for (Book book : books) {
                if ((book.getIdBook ()).equals (idbook)) {
                    listID.add (book.getIdBook ());
                }
            }
                for (String s : listID) {
                    cherk = borrowTools.ReturnBook (s);
                    if (cherk > 0){
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('还书成功！');window.location.href='ReaderDue.jsp';</script></body></html>");
                        break;
                    }else {
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('还书失败');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                            }
                        }

                } else {
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
             }
        }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
