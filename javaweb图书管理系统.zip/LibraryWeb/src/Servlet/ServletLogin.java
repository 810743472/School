package Servlet;

import control.JDBCUtils;
import entity.Borrow;
import sqlTools.BorrowTools;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("content-type","text/html;charset=UTF-8");
            String name =new String ( request.getParameter ("loginName").getBytes ("iso-8859-1"), "utf-8");
            String pwd = new String (request.getParameter ("loginPwd").getBytes ("iso-8859-1"), "utf-8");
            String checkUser = request.getParameter("loginUser");
            boolean checkName = false;
            boolean checkPwd = false;
        JDBCUtils jdbcUtils = new JDBCUtils();
        String sql1 = "select idReader from reader";
        String sql2 = "select nameUser from librarian";
        String sql3 = "select * from reader where idReader ="+"'"+name+"'";
        String sql4 = "select * from librarian where nameUser = "+"'"+name+"'";
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        List<String> lname = new ArrayList<> ();
        Boolean checkTime = true;
        String login_pwd = null;
        try {
            //读者登录
            if (checkUser.equals ("reader")){
                rs1 = jdbcUtils.findAll (sql1);
                while (rs1.next ()){
                    lname.add (rs1.getString ("idReader"));
                }
                for (int i = 0; i < lname.size (); i++) {
                    String login_name = lname.get(i);
                    if (login_name.equals (name) == false){
                    }else {
                        checkName = true;
                    }
                }
                if (checkName == false){
                    response.setContentType ("text/html;charset=gb2312");
                    PrintWriter out = response.getWriter ();
                    out.print ("<script>alert('用户名无效！');window.location.href='javascript:history.go(-1)';</script>");
//                    String a = URLEncoder.encode("用户名错误！", "GB2312");
//                    PrintWriter out = response.getWriter ();
//                    out.print("<html><body><script type='text/javascript'>alert(decodeURIComponent('"+a+"') );window.location.href='javascript:history.go(-1)';</script>");
                }
                if (checkName == true){
                    rs2 = jdbcUtils.findAll (sql3);

                    while (rs2.next ()){
                        login_pwd = rs2.getString ("password");
                    }
                    if (pwd.equals (login_pwd)){
                        BorrowTools borrowTools = new BorrowTools();
                        String loginname = new String (request.getParameter ("loginName").getBytes ("iso-8859-1"), "utf-8");
                        List<Borrow> Borrows = new ArrayList<> ();
                        Borrows = borrowTools.SearchAll ();
                        List<Borrow> borrows = new ArrayList<> ();
                        for (Borrow borrow : Borrows) {
                            if ((borrow.getIdReader ().equals (name))){
                                borrows.add (borrow);
                            }
                        }


                        Date duetime = null;
                        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
                        String lendtime = sdf.format(new Date());
                        HttpSession session = request.getSession ();
                        session.setAttribute ("loginName",name);
                        for (Borrow borrow1 : borrows) {
                            System.out.println (borrow1);
                            duetime = borrow1.getDueDate ();
                            if (sdf.parse (lendtime).getTime () > duetime.getTime ()){
                                checkTime = false;
                                break;
                            }
                        }
                        if (checkTime == false){
//                            response.setContentType ("text/html;charset=gb2312");
//                            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('您有图书借阅时间超时，请尽快归还！');</script></body></html>");
                            request.getRequestDispatcher ("ReaderLogin.jsp").forward (request, response);
                        }else {
                            HttpSession session1 = request.getSession ();
                            session1.setAttribute ("loginName",name);
                            request.getRequestDispatcher ("ReaderLogin.jsp").forward (request, response);
                        }
                    }else{
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('密码错误！');window.location.href='javascript:history.go(-1)';</script></body></html>");

                    }
                }
            }//管理员登录
            else {
                rs1 = jdbcUtils.findAll (sql2);
                while (rs1.next ()) {
                    lname.add (rs1.getString ("nameUser"));
                }
                for (int i = 0; i < lname.size (); i++) {
                    String login_name = lname.get (i);
                    if (login_name.equals (name) == false) {
                    } else {
                        checkName = true;
                    }
                }
                if (checkName == false){
                    response.setContentType ("text/html;charset=gb2312");
                    response.getWriter ().print ("<html><body><script type='text/javascript'>alert('用户名无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                }
                if (checkName == true){
                    rs2 = jdbcUtils.findAll (sql4);

                    while (rs2.next ()){
                        login_pwd = rs2.getString ("password");
                    }
                    if (pwd.equals (login_pwd)){
                        request.getRequestDispatcher ("AdminLogin.jsp").forward (request, response);
                    }else{
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('密码错误！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                    }
                }
            }
        } catch (SQLException | ParseException e) {
            e.printStackTrace ();
        }finally {
            for (String list: lname
                 ) {
                System.out.println (list
                );
                System.out.println (login_pwd);
                System.out.println (pwd);
            }
            }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
