package Servlet;

import entity.Author;
import entity.Book;
import entity.Publisher;
import sqlTools.AuthorTools;
import sqlTools.BookTools;
import sqlTools.PublisherTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletBookAdd")
public class ServletBookAdd extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType ("text/html;charset=UTF-8");
        String idBook = new String (request.getParameter ("idBook").getBytes ("iso-8859-1"), "utf-8");
        String nameBook = new String(request.getParameter ("nameBook").getBytes ("iso-8859-1"), "utf-8");
        String price = new String (request.getParameter("price").getBytes ("iso-8859-1"), "utf-8");
        String kind = new String (request.getParameter("kind").getBytes ("iso-8859-1"), "utf-8");
        String author1 = new String(request.getParameter("author").getBytes ("iso-8859-1"), "utf-8");
        String workplace = new String(request.getParameter("workplace").getBytes ("iso-8859-1"), "utf-8");
        String publisher1 = new String(request.getParameter("publisher").getBytes ("iso-8859-1"), "utf-8");
        String address = new String(request.getParameter("address").getBytes ("iso-8859-1"), "utf-8");

        Book book = new Book();
        BookTools bookTools = new BookTools();

        Author author = new Author();
        AuthorTools authorTools = new AuthorTools();

        Publisher publisher = new Publisher ();
        PublisherTools publisherTools = new PublisherTools();

        if ( idBook != null && !"".equals(idBook)
                && nameBook != null && !"".equals(nameBook)
                && price != null && !"".equals(price)
                && kind != null && !"".equals(kind)
                && author1 != null && !"".equals(author)
                && publisher1 != null && !"".equals(publisher)
                && workplace != null && !"".equals(workplace)
                && address != null && !"".equals(address)) {
            book.setIdBook(idBook);
            book.setNameBook(nameBook);
            book.setPrice(Integer.parseInt(price));

            book.setType(kind);
            book.setAuthor(author1);
            book.setPublisher(publisher1);

            author.setName(author1);
            author.setWorkplace(workplace);

            publisher.setName(publisher1);
            publisher.setAddress(address);

            int j = publisherTools.AddPublisher(publisher);
            int k = authorTools.AddAuthor(author);
            int i = bookTools.AddBook(book);
            if ( i > 0 ) {
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('成功新增图书信息！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                return;
            } else {
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('新增图书信息失败！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                return;
            }
        } else {
            response.setContentType ("text/html;charset=gb2312");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('请输入完整资料！');window.location.href='javascript:history.go(-1)';</script>");

//                response.setContentType ("text/html;charset=gb2312");
//                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('请输入完整资料！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                return;
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
