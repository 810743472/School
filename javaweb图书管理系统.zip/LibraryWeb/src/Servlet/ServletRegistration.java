package Servlet;

import control.JDBCUtils;
import entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.IOException;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletRegistration")
public class ServletRegistration extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType ("text/html;charset=UTF-8");
        JDBCUtils jdbcUtils = new JDBCUtils ();
        User user = new User();
        String ReaderID = new String (request.getParameter ("id").getBytes ("iso-8859-1"), "utf-8");
        String ReaderName = new String (request.getParameter ("name").getBytes ("iso-8859-1"), "utf-8");
        String ReaderType = new String (request.getParameter ("typeLabel").getBytes ("iso-8859-1"), "utf-8");
        String ReaderSex = new String(request.getParameter("sex").getBytes ("iso-8859-1"), "utf-8");
        String ReaderPwd = new String(request.getParameter("password").getBytes ("iso-8859-1"), "utf-8");

        if (ReaderID != null && !"".equals(ReaderID)
                && ReaderName != null && !"".equals(ReaderName)
                && ReaderType != null && !"".equals(ReaderType)
                && ReaderSex != null && !"".equals(ReaderSex)
                && ReaderPwd != null && !"".equals(ReaderPwd) ){
            user.setIdReader (ReaderID);
            user.setNameReader (ReaderName);
            user.setKing (ReaderType);
            user.setSex (ReaderSex);
            user.setPassword (ReaderPwd);
            int row = jdbcUtils.insertInto (user);

            if (row > 0 ) {
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('成功新增读者信息！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                return;
            } else {
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('新增读者信息失败！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                return;
            }
        } else {
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('请输入完整资料');window.location.href='javascript:history.go(-1)';</script></body></html>");
            return;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
