package Servlet;

import control.JDBCUtils;
import entity.Book;
import entity.User;
import sqlTools.BookTools;
import sqlTools.ReaderTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletDeleteReader")
public class ServletDeleteReader extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User reader = new User();
        ReaderTools readerTools = new ReaderTools();
        String ReaderID = null;
        String ID = null;
        int checkID = 0;
        int check = 0;
        List<User> listBooks = new ArrayList<User> ();
        List<String> listID = new ArrayList<> ();
        if ((request.getParameter ("ReaderID") != null) && !"".equals (request.getParameter ("ReaderID"))) {
            ReaderID = new String (request.getParameter ("ReaderID").getBytes ("iso-8859-1"), "utf-8");
            listBooks = readerTools.ReaderDataSearch (ReaderID);
            for (User readerName1 : listBooks) {
                listID.add (readerName1.getNameReader ());
                ID = readerName1.getIdReader ();
            }
            for (String readerName2 : listID) {
                if (ReaderID.equals (readerName2)) {
                    checkID = readerTools.DeleteReader (ID);
                    if (checkID > 0) {
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('成功删除读者！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                    } else {
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('删除读者失败！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                    }
                }

            }
            if (listID.size () == 0){
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('姓名有误！');window.location.href='javascript:history.go(-1)';</script></body></html>");
            }
        }else {
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('姓名不能为空！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
