package Servlet;
import	java.sql.ResultSet;

import entity.Book;
import sqlTools.BookTools;
import sqlTools.BorrowTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletDeleteBook")
public class ServletDeleteBook extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        BookTools bookTools = new BookTools();
        Book book = null;
        String idBook = null;
        int cherk = 0;
        ResultSet rs = null;
        List<Book> list = new ArrayList<> ();
        List<String> listID = new ArrayList<> ();
        BorrowTools borrowTools = new BorrowTools();

        if ((request.getParameter ("idBook") != null) || !"".equals (request.getParameter ("idBook"))) {
            idBook = new String (request.getParameter ("idBook").getBytes ("iso-8859-1"), "utf-8");
            list = bookTools.BookData ();
            for (Book books : list) {
                listID.add (books.getIdBook ());
            }
            for (String bookid : listID) {
                if (idBook.equals (bookid)) {
//                    borrowTools.ReturnBook (idBook);
                    cherk = bookTools.DeleteBook (idBook);

                    if (cherk > 0){
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('删除成功');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                    }else {
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('删除失败');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                    }

                }else {
                    response.setContentType ("text/html;charset=gb2312");
                    response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                    break;
                }
            }
        }else {
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }
        }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
