package Servlet;
import control.JDBCUtils;
import entity.Book;
import sqlTools.BookTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletUpdateBook")
public class ServletUpdateBook extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BookTools bookTools = new BookTools();
        Book book = null;
        JDBCUtils jdbcUtils = new JDBCUtils();
        String authorWorkPlace = null;
        String publisherAddress = null;
        ResultSet rs1 = null;
        ResultSet rs2= null;
        String idBook = null;
        int checkID = 0;
        List<Book> listBooks = new ArrayList<> ();
        List<String> listID = new ArrayList<> ();
        if ((request.getParameter ("idBookText") != null) && !"".equals (request.getParameter ("idBookText"))) {
            idBook = new String (request.getParameter ("idBookText").getBytes ("iso-8859-1"), "utf-8");
            listBooks = bookTools.BookData ();
            for (Book books : listBooks) {
                listID.add (books.getIdBook ());
            }
            for (String bookid : listID) {
               if (idBook.equals (bookid)) {
                    checkID = 1;
                    book = bookTools.Search_Book (idBook);
                    String sql1 = "select * from author where name = '" + book.getAuthor () + "'";
                    String sql2 = "select * from publisher where name = '" + book.getPublisher () + "'";
                    try {
                        if (book != null) {
                            rs1 = jdbcUtils.findAll (sql1);
                            rs2 = jdbcUtils.findAll (sql2);
                            while (rs1.next () && rs2.next ()) {
                                authorWorkPlace = rs1.getString ("workplace");
                                publisherAddress = rs2.getString ("address");
                            }
                        }
                    } catch (SQLException e) {
                        e.printStackTrace ();
                    }
                    break;
                }
            }
        }


            if (idBook != null) {
                request.setAttribute ("idBook", idBook);
            }
            if (book != null) {
                request.setAttribute ("nameBook", book.getNameBook ());
                request.setAttribute ("priceBook", book.getPrice ());
                request.setAttribute ("typeBook", book.getType ());
                request.setAttribute ("authorBook", book.getAuthor ());
                request.setAttribute ("publisherBook", book.getPublisher ());
                request.setAttribute ("workPlaceBook", authorWorkPlace);
                request.setAttribute ("AddressBook", publisherAddress);
            }
            if (checkID == 0){
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }else {
            request.getRequestDispatcher ("UpdateBook.jsp").forward (request,response);

        }


    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
