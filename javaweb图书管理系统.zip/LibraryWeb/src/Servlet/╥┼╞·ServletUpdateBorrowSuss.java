package Servlet;

import entity.Borrow;
import entity.User;
import sqlTools.BorrowTools;
import sqlTools.ReaderTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

@WebServlet("/ServletUpdateBorrowSuss")
public class 遗弃ServletUpdateBorrowSuss extends HttpServlet {
    public class ServletUpdateReaderSuss extends HttpServlet {
        @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            response.setContentType ("text/html;charset=UTF-8");
            String idReader = new String (request.getParameter ("idReader1").getBytes ("iso-8859-1"), "utf-8");
            String idBook = new String (request.getParameter ("idBook1").getBytes ("iso-8859-1"), "utf-8");
            Date lendDate = new Date (request.getParameter ("lendDate1"));
            Date dueDate = new Date (request.getParameter ("dueDate1"));
            String overtime = new String (request.getParameter ("overtime").getBytes ("iso-8859-1"), "utf-8");
            Borrow borrow = new Borrow ();
            BorrowTools borrowTools = new BorrowTools();

            if ((idReader != null && !"".equals (idReader))
                    && (idBook != null && !"".equals (idBook))
                    && (lendDate != null && !"".equals (lendDate))
                    && (dueDate != null && !"".equals (dueDate))
                    && (overtime != null && !"".equals (overtime))
            ) {
                borrow.setIdReader (idReader);
                borrow.setIdBook (idBook);
                borrow.setLendDate (lendDate);
                borrow.setDueDate (dueDate);
                borrow.setOvertime (overtime);
//                int i = 0;
                int i = borrowTools.BorrowInsert (borrow);
                if (i > 0) {
                    response.getWriter ().print ("<html><body><script type='text/javascript'>alert('成功更新借阅信息！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                } else {
                    response.getWriter ().print ("<html><body><script type='text/javascript'>alert('更新借阅信息失败！');window.location.href='javascript:history.go(-1)';</script></body></html>");

                }
            } else {
                PrintWriter out = response.getWriter ();
                out.print ("<script>alert('请输入完整资料！');window.location.href='javascript:history.go(-1)';</script>");
            }
        }

        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            this.doPost (request, response);
        }
    }
}