package Servlet;

import entity.Book;
import org.apache.catalina.Session;
import sqlTools.BookTools;
import sqlTools.BorrowTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletReaderLend")
public class ServletReaderLend extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String booksid =new String ( request.getParameter ("Bookid").getBytes ("iso-8859-1"), "utf-8");
        BorrowTools borrowTools = new BorrowTools();
        Book  book = new Book ();
        BookTools bookTools = new BookTools();
        book = bookTools.Search_Book (booksid);
        List<Book> list = new ArrayList<> ();
        List<String> listID = new ArrayList<> ();
        List<Book> bookid = bookTools.BookData ();
        List<Book> books = new ArrayList<> ();

        String LoginName =new String ( request.getParameter ("LoginName").getBytes ("iso-8859-1"), "utf-8");
        int cherk = 0;

        bookid = bookTools.BookData ();
        //把属于borrow的书保存
        for (Book book1 : bookid) {
            if (borrowTools.whetherInStock (book1.getIdBook ()) == true){
                books.add (book1);
            }
        }


        if (booksid != null && !booksid.equals ("")) {
            list = bookTools.BookData ();
            for (Book book1 : books) {
                listID.add (book1.getIdBook ());
            }
            for (String idbook : listID) {
                if (idbook.equals (booksid)) {
                    cherk = borrowTools.BorrowBook (LoginName,booksid);

                    if (cherk > 0){
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('借阅成功！');window.location.href='Readerlend.jsp';</script></body></html>");
                        break;
                    }else {
                        response.setContentType ("text/html;charset=gb2312");
                        response.getWriter ().print ("<html><body><script type='text/javascript'>alert('借阅失败');window.location.href='javascript:history.go(-1)';</script></body></html>");
                        break;
                    }

                }else {
                    response.setContentType ("text/html;charset=gb2312");
                    response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
                    break;
                }
            }
        }else {
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('图书编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
