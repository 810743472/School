package Servlet;

import control.JDBCUtils;
import entity.Borrow;
import entity.User;
import sqlTools.BorrowTools;
import sqlTools.ReaderTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ServletUpdateBorrow")
public class 遗弃ServletUpdateBorrow extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BorrowTools BorrowTools = new BorrowTools ();
        Borrow borrow = null;
        JDBCUtils jdbcUtils = new JDBCUtils();
        ResultSet rs = null;
        String BookID = null;
        int checkID = 0;
        List<Borrow> listBorrows = null;
        List<String> listID = new ArrayList<> ();
        if ((request.getParameter ("idBorrow") != null) && !"".equals (request.getParameter ("idBorrow"))) {
            BookID = new String (request.getParameter ("idBorrow").getBytes ("iso-8859-1"), "utf-8");
            listBorrows = BorrowTools.selcetAll ();
            for (Borrow borrow1s : listBorrows) {
                listID.add (borrow1s.getIdBook ());
            }
            for (String readerID : listID) {
                if (BookID.equals (readerID)){
                    checkID = 1;
                    borrow = BorrowTools.selcet (BookID);
                    break;
                }
            }
        }

        if (BookID != null){
            request.setAttribute ("idBook1", BookID);
        }
        if (borrow != null){
            request.setAttribute ("idReader1", borrow.getIdReader ());
            request.setAttribute ("lendDate1", borrow.getLendDate ());
            request.setAttribute ("dueDate1", borrow.getDueDate ());
            request.setAttribute ("overtime", borrow.getOvertime ());
        }
        if (checkID == 0){
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }else {

        }



    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
