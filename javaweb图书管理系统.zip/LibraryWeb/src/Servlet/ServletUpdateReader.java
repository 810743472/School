package Servlet;
import java.io.Reader;
import	java.util.ArrayList;
import	java.sql.ResultSet;

import control.JDBCUtils;
import entity.Book;
import entity.User;
import sqlTools.ReaderTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletUpdateReader")
public class ServletUpdateReader extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ReaderTools ReaderTools = new ReaderTools();
        User user = new User();
        JDBCUtils jdbcUtils = new JDBCUtils();
        ResultSet rs = null;
        String ReaderID = null;
        int checkID = 0;
        List<User> listReaders = new ArrayList<User> ();
        List<String> listID = new ArrayList<> ();
        if ((request.getParameter ("idReaderText") != null) && !"".equals (request.getParameter ("idReaderText"))) {
            ReaderID = new String (request.getParameter ("idReaderText").getBytes ("iso-8859-1"), "utf-8");
            listReaders = ReaderTools.ReaderData ();
            for (User users : listReaders) {
                listID.add (users.getIdReader ());
            }
            for (String readerID : listID) {
                if (ReaderID.equals (readerID)){
                    checkID = 1;
                    user = ReaderTools.ReaderData (readerID);
                    break;
                }
            }
        }

        if (ReaderID != null){
            request.setAttribute ("ReaderID", ReaderID);
        }
        if (user != null){
            request.setAttribute ("nameReader1", user.getNameReader ());
            request.setAttribute ("kind1", user.getKing ());
            request.setAttribute ("sex1", user.getSex ());
            request.setAttribute ("password1", user.getPassword ());
        }
        if (checkID == 0){
            response.setContentType ("text/html;charset=gb2312");
            response.getWriter ().print ("<html><body><script type='text/javascript'>alert('编号无效！');window.location.href='javascript:history.go(-1)';</script></body></html>");
        }else {
            request.getRequestDispatcher ("UpdateReader.jsp").forward (request,response);

        }


        }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
