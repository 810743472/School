package Servlet;

import entity.User;
import sqlTools.ReaderTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
/**
 * @author sunyongzheng
 */
@WebServlet("/ServletUpdateReaderSuss")
public class ServletUpdateReaderSuss extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType ("text/html;charset=UTF-8");
        String ReaderID = new String (request.getParameter ("idReaderText1").getBytes ("iso-8859-1"), "utf-8");
        String ReaderName = new String(request.getParameter ("nameBookText").getBytes ("iso-8859-1"), "utf-8");
        String ReaderKind = new String (request.getParameter("kindText").getBytes ("iso-8859-1"), "utf-8");
        String ReaderSex = new String (request.getParameter("sexText").getBytes ("iso-8859-1"), "utf-8");
        String ReaderPwd = new String(request.getParameter("passwordText").getBytes ("iso-8859-1"), "utf-8");

        User user = new User();
        ReaderTools readerTools = new ReaderTools();

        if ((ReaderID != null && !"".equals (ReaderID))
        && (ReaderName != null && !"".equals (ReaderID))
         && (ReaderKind != null && !"".equals (ReaderKind))
         && (ReaderSex != null && !"".equals (ReaderSex))
         && (ReaderPwd != null && !"".equals (ReaderPwd))
        ){
            user.setIdReader (ReaderID);
            user.setNameReader (ReaderName);
            user.setKing (ReaderKind);
            user.setSex (ReaderSex);
            user.setPassword (ReaderPwd);

            int i = readerTools.UpdateReader (user);
            if (i > 0){
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('成功更新读者信息！');window.location.href='javascript:history.go(-1)';</script></body></html>");
            }else {
                response.setContentType ("text/html;charset=gb2312");
                response.getWriter ().print ("<html><body><script type='text/javascript'>alert('更新读者信息失败！');window.location.href='javascript:history.go(-1)';</script></body></html>");

            }
        } else {
            PrintWriter out = response.getWriter();
            out.print("<script>alert('请输入完整资料！');window.location.href='javascript:history.go(-1)';</script>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost (request, response);
    }
}
