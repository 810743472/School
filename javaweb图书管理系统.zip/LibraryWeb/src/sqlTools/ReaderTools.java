package sqlTools;

import control.JDBCUtils;
import entity.User;


import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReaderTools {
	/**
	 * @author sunyongzheng
	 * @return 返回特定编号的读者，List<Reader>，获得查找到的对象，存在Java类集list中，并返回list。
	 */
	public User ReaderData(String idReader) {
		String sql = "select idReader,nameReader,kind,sex,password from Reader where idReader =" + idReader + "";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		ResultSet rs = null;
		List<User> ls = new ArrayList<>();
		User reader = null;
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				 reader = new User ();
				reader.setIdReader(rs.getString("idReader"));
				reader.setNameReader(rs.getString("nameReader"));
				reader.setKing (rs.getString("kind"));
				reader.setSex(rs.getString("sex"));
				reader.setPassword(rs.getString("password"));
				ls.add(reader);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return reader;
	}

	/**
	 *
	 * @return 返回特定编号的读者，List<Reader>，获得查找到的对象，存在Java类集list中，并返回list。
	 */
	public List<User> ReaderDataSearch(String nameReader) {
		String sql = "select idReader,nameReader,kind,sex,password from Reader where nameReader like'%" + nameReader
				+ "%'";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		ResultSet rs = null;
		List<User> ls = new ArrayList<>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				User reader = new User();
				reader.setIdReader(rs.getString("idReader"));
				reader.setNameReader(rs.getString("nameReader"));
				reader.setKing (rs.getString("kind"));
				reader.setSex(rs.getString("sex"));
				reader.setPassword(rs.getString("password"));
				ls.add(reader);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	/**
	 *
	 * @return 返回全部读者，List<Reader>，获得查找到的对象，存在Java类集list中，并返回list。
	 *
	 */
	public List<User> ReaderData() {
		String sql = "select idReader,nameReader,kind,sex,password from Reader";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		ResultSet rs = null;
		List<User> ls = new ArrayList<>();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery(sql);
			while (rs.next()) {
				User reader = new User ();
				reader.setIdReader(rs.getString("idReader"));
				reader.setNameReader(rs.getString("nameReader"));
				reader.setKing(rs.getString("kind"));
				reader.setSex(rs.getString("sex"));
				reader.setPassword(rs.getString("password"));
				ls.add(reader);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}

	/**
	 * @return 验证用户名和密码是否正确，正确返回True，错误返回False
	 *
	 */
	public boolean ReaderLogin(String idReader, String password) {
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			String sql = "select idReader,password from reader where idReader='" + idReader + "' and password='"
					+ password + "'";
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				return true;
			}
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 *
	 * @return 进行数据插入操作，插入对应的Reader对象。 返回值： (1) SQL 数据操作语言 (DML) 语句的行数 (2)
	 *         对于无返回内容的 SQL 语句，返回 0
	 */
	public int AddReader(User reader) {
		int i = 0;
		String sql = "insert into reader (idReader,nameReader,kind,sex,password)values(?,?,?,?,?)";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, reader.getIdReader());
			st.setString(2, reader.getNameReader());
			st.setString(3, reader.getKing ());
			st.setString(4, reader.getSex());
			st.setString(5, reader.getPassword());
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	/**
	 *
	 * @return 进行数据更新操作，更新对应的Reader对象。
	 *         对于无返回内容的 SQL 语句，返回 0
	 */
	public int UpdateReader(User reader) {
		int i = 0;
		String sql = "update reader set idReader=?,nameReader=?,kind=?,sex=?,password=? where idReader=?";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, reader.getIdReader());
			st.setString(2, reader.getNameReader());
			st.setString(3, reader.getKing ());
			st.setString(4, reader.getSex());
			st.setString(5, reader.getPassword());
			st.setString(6, reader.getIdReader());
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	/**
	 *
	 * @return 进行数据删除操作，删除对应的Reader对象。
	 *         对于无返回内容的 SQL 语句，返回 0
	 */
	public int DeleteReader(String idreader) {
		int i = 0;
		String sql = "delete from reader where idReader=?";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, idreader);
			i = st.executeUpdate();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
}
