package sqlTools;
import java.sql.SQLException;
import	java.util.ArrayList;

import control.JDBCUtils;
import entity.Book;

import java.sql.ResultSet;
import java.util.List;

/**
 * @author sunyongzheng
 */
public class SearchBooks {
    public List<Book> SearchBooks() {
        String sql = "selecct * from book";
        ResultSet rs = null;
        JDBCUtils jdbcUtils = new JDBCUtils ();
        Book book = new Book ();
        List<Book> list = new ArrayList<Book> ();
        try {
            rs = jdbcUtils.findAll (sql);
            while (rs.next()) {
                book.setIdBook (rs.getString ("idBook"));
                book.setNameBook (rs.getString ("nameBook"));
                book.setPrice (rs.getInt ("price"));
                book.setType (rs.getString ("kind"));
                book.setAuthor (rs.getString ("author"));
                book.setPublisher (rs.getString ("publisher"));
                list.add (book);
            }

        } catch (SQLException e) {
            e.printStackTrace ();
        }

        return list;
    }
}
