package sqlTools;

import control.JDBCUtils;

import entity.Book;
import entity.Borrow;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author sunyongzheng
 * @return 按照读者编号查找借阅的图书
 */
public class BorrowTools {
	/**
	 *
	 * @return 多表查询，返回编号对应读者所借书目
	 */
	public List<Book> BookData(String idReader) {
		String sql="select book.idBook,nameBook,price,book.kind,author,publisher from reader,borrow,book "
				+ "where book.idBook = borrow.idBook and reader.idReader = borrow.idReader "
				+ "and reader.idReader = '" + idReader + "'";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		ResultSet rs=null;
		List<Book> ls=new ArrayList<Book>();
		try {
			PreparedStatement st =conn.prepareStatement(sql);
			rs=st.executeQuery(sql);
			while(rs.next()){
				Book book=new Book();
				book.setIdBook(rs.getString("idBook"));
				book.setNameBook(rs.getString("nameBook"));
				book.setPrice(rs.getInt("price"));
				book.setType(rs.getString("kind"));
				book.setAuthor(rs.getString("author"));
				book.setPublisher(rs.getString("publisher"));
				ls.add(book);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
	/**
	 * 根据读者编号，返回borrow
	 */
	public  List<Borrow> findBorrows(String idReader) {
	    Borrow borrow = new Borrow();
	    List<Borrow> borrows = new ArrayList<> ();

	    JDBCUtils jdbcUtils = new JDBCUtils();
	    String sql = "select * from borrow where idReader = '"+idReader+"'";
	    Connection conn = jdbcUtils.getConnection ();
	    ResultSet rs = null;
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery ();
			while (rs.next()) {
				borrow.setIdReader (rs.getString ("idReader"));
				borrow.setIdBook (rs.getString ("idBook"));
				borrow.setLendDate (rs.getDate ("lendDate"));
				borrow.setDueDate (rs.getDate ("dueDate"));
				borrow.setOvertime (rs.getString ("overtime"));
			   borrows.add (borrow);
			}
			st.close ();
			rs.close ();
			conn.close ();
		} catch (SQLException e) {
			e.printStackTrace ();
		}
		return  borrows;

	}
	/**
	 *
	 * @return 多表查询，返回编号对应读者所借书目
	 */
	public List<Book> BookData_Search_idBook(String idBook) {
		String sql="select book.idBook,nameBook,price,book.kind,author,publisher from book where book.idBook = '" + idBook + "'";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();

		ResultSet rs=null;
		List<Book> ls=new ArrayList<Book>();
		try {
			PreparedStatement st =conn.prepareStatement(sql);
			rs=st.executeQuery(sql);
			while(rs.next()){
				Book book=new Book();
				book.setIdBook(rs.getString("idBook"));
				book.setNameBook(rs.getString("nameBook"));
				book.setPrice(rs.getInt("price"));
				book.setType(rs.getString("kind"));
				book.setAuthor(rs.getString("author"));
				book.setPublisher(rs.getString("publisher"));
				ls.add(book);
			}
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ls;
	}
	/**
	 * 查询所有的借阅信息
	 * @return 返回列表
	 */
	public List<Borrow> selcetAll(){
		String sql = "select idReader,idBook,lendDate,dueDate,overtime from borrow";
		JDBCUtils db = new JDBCUtils ();
		List<Borrow> li = new ArrayList<> ();
		Connection conn = db.getConnection ();
		ResultSet rs = null;
		try {
			PreparedStatement st = conn.prepareStatement (sql);
			rs = st.executeQuery (sql);
			while (rs.next ()){
				Borrow borrow = new Borrow ();
				borrow.setIdReader (rs.getString ("idReader"));
				borrow.setIdBook (rs.getString ("idBook"));
				borrow.setLendDate (rs.getDate ("lendDate"));
				borrow.setDueDate (rs.getDate ("dueDate"));
				borrow.setOvertime (rs.getString ("overtime"));
				li.add (borrow);
			}
			rs.close ();
			st.close ();
			conn.close ();
		} catch (SQLException e) {
			e.printStackTrace ();
		}

		return li;
	}
	/**
	 * 查询特定编号书
	 * @return 返回书
	 */
	public Borrow selcet(String BookID){
		String sql = "select idReader,idBook,lendDate,dueDate,overtime from borrow where idBook = '"+ BookID +"'";
		JDBCUtils db = new JDBCUtils ();
		ResultSet rs = null;
		Connection conn = db.getConnection ();
		Borrow borrow = null;
		try {
			PreparedStatement st = conn.prepareStatement (sql);
			rs = st.executeQuery (sql);
			while (rs.next ()){
				borrow = new Borrow ();
				borrow.setIdReader (rs.getString ("idReader"));
				borrow.setIdBook (rs.getString ("idBook"));
				borrow.setLendDate (rs.getDate ("lendDate"));
				borrow.setDueDate (rs.getDate ("dueDate"));
				borrow.setOvertime (rs.getString ("overtime"));
			}
			rs.close ();
			st.close ();
			conn.close ();
		} catch (SQLException e) {
			e.printStackTrace ();
		}

		return borrow;
	}
	/**
	 * 根据编号查询borrow，并返回图书类
	 */
	public Date lendtime(String BookID){
		String sql1 = "select idReader,idBook,lendDate,dueDate,overtime from borrow where idBook = '"+ BookID +"'";
		String sql2 = "select idReader,idBook,lendDate,dueDate,overtime from book where idBook = '"+ BookID +"'";
		JDBCUtils db = new JDBCUtils ();
		ResultSet rs = null;
		Connection conn = db.getConnection ();
		Borrow borrow = null;
		Date lendtime = null;
		try {
			PreparedStatement st = conn.prepareStatement (sql1);
			rs = st.executeQuery (sql1);
			while (rs.next ()){
				 lendtime = new Date ();
				lendtime = rs.getDate ("lendtime");
			}
			rs.close ();
			st.close ();
			conn.close ();
		} catch (SQLException e) {
			e.printStackTrace ();
		}

		return lendtime;
	}


	/**
	 *
	 * @return 返回该书是否在库，在库为true，借出为false
	 */	public boolean whetherInStock(String idBook) {
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		String sql = "select * from borrow ";
		try {
			PreparedStatement st =conn.prepareStatement(sql);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				if(rs.getString("idBook")!=null){
					if(rs.getString("idBook").equals(idBook)){
						return false;
					}
				}
			}
			st.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}
	/**
	 * 返回所有borrow
	 *
	 */
	public List<Borrow> SearchAll() {
		List<Borrow> li = new ArrayList<> ();
		String sql = "select * from borrow";
		JDBCUtils jdbcUtils = new JDBCUtils ();
		Connection conn = jdbcUtils.getConnection ();
		ResultSet rs = null;
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			rs = st.executeQuery ();
			while (rs.next ()){
				Borrow borrow = new Borrow ();
				borrow.setIdReader (rs.getString ("idReader"));
				borrow.setIdBook (rs.getString ("idBook"));
				borrow.setLendDate (rs.getDate ("lendDate"));
				borrow.setDueDate (rs.getDate ("dueDate"));
				borrow.setOvertime (rs.getString ("overtime"));
				li.add (borrow);
			}
			st.close ();
			rs.close ();
			conn.close ();
		} catch (SQLException e) {
			e.printStackTrace ();
		}
		return li;
	}

    /**
     * 插入自定义的数据
     */
    public int BorrowInsert(Borrow borrow){
        int i = 0;
        String sql = "update borrow set idReader = ?,nameReader=?,kind=?,sex=?,password=? where idBook=?";
        JDBCUtils jdbcUtils = new JDBCUtils ();
        Connection conn = jdbcUtils.getConnection ();
        try {
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString (1,borrow.getIdReader ());
            st.setString (2,borrow.getIdBook ());
            st.setDate (3, (java.sql.Date) borrow.getLendDate ());
            st.setDate (4, (java.sql.Date) borrow.getDueDate ());
            st.setString (5,borrow.getOvertime ());
        } catch (SQLException e) {
            e.printStackTrace ();
        }
        return i;
    }

	/**
	 *
	 * @return 进行数据插入操作，加入借阅的信息
	 * 返回值：
	 * 对于无返回内容的 SQL 语句，返回 0
	 */
	public int BorrowBook(String idReader,String idbook) {
		int i=0;
		String sql="insert into borrow (idReader,idbook,lendDate,dueDate,overtime)values(?,?,"
				+ "CURRENT_DATE(),DATE_ADD(CURRENT_DATE(),INTERVAL 2 MONTH),'否')";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			PreparedStatement st = conn.prepareStatement(sql);		
			st.setString(1, idReader);
			st.setString(2, idbook);
			i=st.executeUpdate();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}
	/**
	 * @return
	 * 进行数据删除操作，删除借阅的信息，表示归还图书
	 * 对于无返回内容的 SQL 语句，返回 0
	 */
	public int ReturnBook(String idbook) {
		int i=0;
		String sql="delete from borrow where idBook=?";
		JDBCUtils db = new JDBCUtils ();
		Connection conn = db.getConnection ();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, idbook);
			i=st.executeUpdate();
			st.close();
			conn.close();
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return i;
	}
}
