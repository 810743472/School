package entity;
/**
 * @author sunyongzheng
 */
public class User {
    private String idReader;
    private String nameReader;
    private String king;
    private String sex;
    private String password;

    public User() {
    }

    public User(String idReader, String nameReader, String king, String sex, String password) {
        this.idReader = idReader;
        this.nameReader = nameReader;
        this.king = king;
        this.sex = sex;
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "idReader='" + idReader + '\'' +
                ", nameReader='" + nameReader + '\'' +
                ", king='" + king + '\'' +
                ", sex='" + sex + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    public String getIdReader() {
        return idReader;
    }

    public void setIdReader(String idReader) {
        this.idReader = idReader;
    }

    public String getNameReader() {
        return nameReader;
    }

    public void setNameReader(String nameReader) {
        this.nameReader = nameReader;
    }

    public String getKing() {
        return king;
    }

    public void setKing(String king) {
        this.king = king;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
