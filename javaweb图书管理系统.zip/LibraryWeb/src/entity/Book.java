package entity;

import java.util.Objects;
/**
 * @author sunyongzheng
 */
public class Book {
    private String idBook;
    private String nameBook;
    private int price;
    private String type;
    private String author;
    private String publisher;//出版社

    public String getIdBook() {
        return idBook;
    }

    public void setIdBook(String idBook) {
        this.idBook = idBook;
    }

    public String getNameBook() {
        return nameBook;
    }

    public void setNameBook(String nameBook) {
        this.nameBook = nameBook;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass () != o.getClass ()) return false;
        Book book = (Book) o;
        return price == book.price &&
                Objects.equals (idBook, book.idBook) &&
                Objects.equals (nameBook, book.nameBook) &&
                Objects.equals (type, book.type) &&
                Objects.equals (author, book.author) &&
                Objects.equals (publisher, book.publisher);
    }

    @Override
    public int hashCode() {
        return Objects.hash (idBook, nameBook, price, type, author, publisher);
    }

    @Override
    public String toString() {
        return "Book{" +
                "idBook='" + idBook + '\'' +
                ", nameBook='" + nameBook + '\'' +
                ", price=" + price +
                ", type='" + type + '\'' +
                ", author='" + author + '\'' +
                ", publisher='" + publisher + '\'' +
                '}';
    }
}
