package control;

import entity.User;

import java.sql.*;

/**
 * @author sunyongzheng
 */
public class JDBCUtils {
    private Connection connection = null;
    private Statement stmt = null;
    private ResultSet rs = null;


    public Connection getConnection() {
        String url = "jdbc:mysql://localhost:3306/library?serverTimezone=UTC&useUnicode=true&characterEncoding=utf-8";
        String user = "root";
        String password = "123456";


        try {
            Class.forName ("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(url,user,password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace ();
        }

        return connection;
    }
    //插入
    public int insertInto(User user){
        connection = getConnection ();
        String IdReader = user.getIdReader ();
        String sql = "insert into reader values ("+"'"+user.getIdReader ()+"','"+user.getNameReader ()+"','"+user.getKing ()+"','"+user.getSex ()+"','"+user.getPassword ()+"') ";
        int row = 0;
        try {
            stmt = connection.createStatement ();
            row = stmt.executeUpdate (sql);
        } catch (Exception e) {
            e.printStackTrace ();

        }
        return row;
    }
    public int dropAll(String sql){
        connection = getConnection ();
        int row = 0;
        try {
            stmt = connection.createStatement ();
            row = stmt.executeUpdate (sql);
        } catch (Exception e) {
            e.printStackTrace ();

        }
        return row;
    }
    //查询
    public ResultSet findAll(String sql) throws SQLException {
        connection = getConnection ();
        stmt = connection.createStatement();
        //查询
        rs = stmt.executeQuery(sql);
        return rs;
    }
    public void closeAll(ResultSet rs,Statement stmt,Connection connection) throws SQLException {
        if(rs!=null){
            rs.close ();
        }
        if (stmt != null){
            stmt.close();
        }
        if (connection != null){
            connection.close();
        }
    }
}

